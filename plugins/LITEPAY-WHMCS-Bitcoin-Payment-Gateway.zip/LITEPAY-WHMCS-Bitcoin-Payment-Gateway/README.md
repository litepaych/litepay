LITEPAY WHMCS Bitcoin Payment Extension
=======================================

This is a WHMCS Bitcoin Payment module for WHMCS from LITEPAY.ch, which allows your shop to accept bitcoin payments in minutes. It is based on LITEPAY.ch API, you can read about it at https://litepay.ch/api_merchant_doc. This module works based on API calls to our server, you don't need to register or request keys.

Instalation takes a minute, just upload the files from this archive in your WHMCS folder and activate it.

**REGISTRATION**

1. In order for the plugin to work, you will need to register for a Secret Key and VendorID on our website. 
   Please use the following link to register for Merchant API https://litepay.ch/merchant/ 
2. Once you have received the Secret Key and VendorID, you can continue with the Instalation.


**INSTALLATION**

1. Upload module content to your WHMCS folder.
    
**CONFIGURATION**

2. Go to Setup -> Payments -> Payment Gateways -> All Payment Gateways
3. Select "LitePay.ch PayGate" and press Activate
4. Enter
   - Secret Key; (You got when registering on our website)
   - Vendor ID; (You got when registering on our website)
5. Convert To For Processing:
   - If you sell in a different currency, you will need to activate this function and mark USD as default currency.
   - Doing that will let the plugin know you are using a different currency & it will calculate the rate of the price in dollars.

== Frequently Asked Questions ==

= How does the plugin works? =

  Quite easy, once a order has been created and the user proceeded to checkout, the plugin will redirect to the litepay merchant payment page, 
  where the buyer will be directed to pay the invoice. If the invoice has been paid, the buyer will be redirected back to the website where he 
  placed the order, displaying the created order. If the invoice is not paid, it will remain in limbo (30 days) until its paid. 

= The plugin does not work =
  Make sure you have the correct WHMCS version installed. 
  the VendorID and Secret Key correctly written in the settings page.

  You can contact us with screenshots of the errors to info@litepay.ch and we will provide support.   


**INFORMATION** 
Version 1.2

If you need any further support regarding our services you can contact us via:
E-mail: [info@litepay.ch]
Web: [https://litepay.ch]
Telegram: [https://t.me/joinchat/FwEsmUbVFEENQyuPSbXpkA]

Bitcoin wallets you can use:
Electrum: [https://electrum.org]
Jaxx: [https://jaxx.io]
