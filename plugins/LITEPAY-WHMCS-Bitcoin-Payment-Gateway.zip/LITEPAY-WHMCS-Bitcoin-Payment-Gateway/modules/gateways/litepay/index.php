<?php
ob_start();
header('Location: ' . $_SERVER['SERVER_NAME']);