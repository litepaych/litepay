<?php

class CreateOrderRequest
{
	private $orderId;
	private $payAmount;
	private $callbackUrl;
	private $successUrl;

	/**
	 * @param $orderId
	 * @param $payAmount - Customer pay amount in calculation currency
	 * @param $callbackUrl
	 * @param $successUrl
	 */
	function __construct($orderId, $payAmount, $callbackUrl, $successUrl)
	{
		$this->orderId = $orderId;
		$this->payAmount = $payAmount;
		$this->callbackUrl = $callbackUrl;
		$this->successUrl = $successUrl;
	}

	/**
	 * @return string
	 */
	public function getPayAmount()
	{
		return FormattingUtil::formatCurrency($this->payAmount == null ? 0.0 : $this->payAmount);
	}


	/**
	 * @return string
	 */
	public function getOrderId()
	{
		return $this->orderId == null ? '' : $this->orderId;
	}
	
	/**
	 * @return string
	 */
	public function getCallbackUrl()
	{
		return $this->callbackUrl == null ? '' : $this->callbackUrl;
	}

	/**
	 * @return string
	 */
	public function getSuccessUrl()
	{
		return $this->successUrl == null ? '' : $this->successUrl;
	}
}