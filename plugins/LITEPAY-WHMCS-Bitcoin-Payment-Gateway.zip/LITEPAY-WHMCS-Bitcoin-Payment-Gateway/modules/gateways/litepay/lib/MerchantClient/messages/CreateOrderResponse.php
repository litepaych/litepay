<?php

class CreateOrderResponse
{

	private $url;

	/**
	 * @param $url
	 */
	function __construct($url)
	{
		$this->url = $url;
	}

	/**
	 * @return String
	 */
	public function getUrl()
	{
		return $this->url;
	}

}