<?php
include '../../../init.php';
include '../../../includes/functions.php';
include '../../../includes/gatewayfunctions.php';
include '../../../includes/invoicefunctions.php';
require_once 'lib/MerchantClient/MerchantClient.php';

$gatewaymodule = "litepay";
$GATEWAY = getGatewayVariables($gatewaymodule);
$options = $_POST;
$invoiceId = (int)$_POST['invoiceId'];
$convertto = (int)$GATEWAY['convertto'];
$secretID = $GATEWAY['secretID'];
$vendorID = $GATEWAY['vendorID'];
$merchantApiUrl = 'https://litepay.ch/p/';
$currency = $price = false;

/*
If converto is not OFF(0) search for the currency and set the price for the gateway.
This is used only if the module has convertofrom active in the gateway preferences. 
and a different currency as default/or for a specific invoice.
 */
if ($convertto != 0) {
    //user chose
    //get the invoice
    $get_invoice = localAPI('GetInvoice',['invoiceid' => $invoiceId]);
    
    if ($get_invoice['result'] == 'success') {
        $userid = $get_invoice['userid'];
        $invoice_price = $get_invoice['total'];
        $notes = $get_invoice['notes'];
    } else {
        $userid = false;
    }
    
    //get the currency of the invoice
    if ($userid != false) {
        $get_invoices = localAPI('GetInvoices', ['userid' => $userid,'limitnum' => 1,'orderby' => $invoiceId]); 
            if ($get_invoices['result'] == 'success') {
                $currency = $get_invoices['invoices']['invoice'][0]['currencycode']; 
            } else {
                error_log('no currency found for invoice ' . $invoiceId);
                die("no currency found for invoice  ".$invoiceId); 
            }

    } else {
        error_log('no user id found for invoice ' . $invoiceId);
        die("no user id found for invoice  ".$invoiceId);       
    }

    //get all the currencies
    $result = localAPI('GetCurrencies', array());
    if ($result['result'] == 'success') {
        $default = $result['currencies']['currency'][0]['code']; //default currency
        $default_rate = $result['currencies']['currency'][0]['rate']; //1.00000
        if ($default == "USD") { 
            error_log('You need to disable "Convert To For Processing" due to the fact that USD is your default coin. This is used if you have a different default coin');
            die('You need to disable "Convert To For Processing" due to the fact that USD is your default coin. This is used if you have a different default coin'); 
            
        }
        $currency_rate;  $usd_rate;
        foreach($result['currencies']['currency'] as $currencies) {
            if ($currencies['code'] == 'USD') {
                $usd_rate = $currencies['rate'];
            }
            if ($currencies['code'] == $currency) {
                $currency_rate = $currencies['rate'];
            }
        }
        
        if ($currency == 'USD') { 
            $amount = $invoice_price;
            $notes = $notes;
        } else {
            $total = (($invoice_price / $currency_rate) * $usd_rate);
            $amount = number_format($total,2);

             $note = array('description' => 'Invoice id #'.$invoiceId. ' -- ' .$invoice_price. ' '.$currency.' @ '.$currency_rate.' '.$currency.'/USD * '.$usd_rate.' '.$default.'/USD = '.$amount.' USD');
             localAPI(LogActivity, $note);
             localAPI('UpdateInvoice', ['invoiceid' => $invoiceId, 'notes' => 'Invoice currency change, from '.$currency.' to USD. New price is '.$amount.' USD']); 
            }
        
    } else {
        error_log('unable to get currencies ');
        die("unable to get currencies");      
    }
       
 //default currency 
} else {
    //else go along with the invoice price, considering it is defaulted on USD
    $data = localAPI('GetInvoice', ['invoiceid' => $invoiceId]);

    if (!$data) {
        error_log('No invoice found for invoice id' . $invoiceId);
        die("Invalid invoice. ".$invoiceId);
    }

    $amount = $data['total'];
    $notes = $data['notes'];
    
}

if (!$secretID || !$vendorID)
{
    echo 'Plugin is not fully configured. Please select different payment option';
    exit;
}

if ($amount <= 0) {
    error_log('Plugin error. Amount is negative or 0 => '.$amount);
    echo 'Plugin is not fully configured. Please select different payment option. Amount is negative or 0 => '.$amount;
    exit;
}

$orderDescription = "Order #{$invoiceId}";
$callbackUrl = $options['systemURL'] . '/modules/gateways/callback/litepay.php?invoice_id=' . $invoiceId .'&secret='. $secretID;
$successUrl = $options['systemURL'] . '';
//in the future.
$cancelUrl = $options['systemURL'] . '/modules/gateways/callback/litepay.php?cancel&invoice_id=' . $invoiceId;


$client = new MerchantClient($merchantApiUrl, $secretID, $vendorID);
$orderRequest = new CreateOrderRequest($invoiceId, $amount, $callbackUrl, $successUrl);
$response = $client->createOrder($orderRequest);


if ($response instanceof ApiError) {
    error_log('Error: '.$response);
    exit('Error: contact the mother ship. ');
} else {
    $url = $response->getUrl();
    header('Location: ' . $url);
}
?>
