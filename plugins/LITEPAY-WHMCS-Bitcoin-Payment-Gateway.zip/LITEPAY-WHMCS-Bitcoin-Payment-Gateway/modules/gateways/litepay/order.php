<?php
include '../../../init.php';
include '../../../includes/functions.php';
include '../../../includes/gatewayfunctions.php';
include '../../../includes/invoicefunctions.php';
require_once 'lib/MerchantClient/MerchantClient.php';

$gatewaymodule = "litepay";
$GATEWAY = getGatewayVariables($gatewaymodule);
$options = $_POST;
$invoiceId = (int)$_POST['invoiceId'];
$convertto = (int)$GATEWAY['convertto'];
$secretID = $GATEWAY['secretID'];
$vendorID = $GATEWAY['vendorID'];
$merchantApiUrl = 'https://litepay.ch/p/';
$currency = $price = false;

/*
If converto is not OFF(0) search for the currency and set the price for the gateway.
This is used only if the module has convertofrom active in the gateway preferences. 
and a different currency as default/or for a specific invoice.
 */
if ($convertto != 0) {
    
    //get the invoice
    $postData = array('invoiceid' => $invoiceId);  
    $get_invoice = localAPI('GetInvoice',$postData);
    
    if ($get_invoice['result'] == 'success') {
        $userid = $get_invoice['userid'];
        $invoice_price = $get_invoice['total'];
        $notes = $get_invoice['notes'];
    } else {
        $userid = false;
    }
    
    //get the currency of the invoice
    if ($userid != false) {
            $postData = array(
            'userid' => $userid,
            'limitnum' => 1,
            'orderby' => $invoiceId
        );

        $get_invoices = localAPI('GetInvoices', $postData);
        if ($get_invoices['result'] == 'success') {
            $currency = $get_invoices['invoices']['invoice'][0]['currencycode']; 
        } else {
            $currency = false;
        }
        
    } else {
        error_log('no user id found for invoice ' . $invoiceId);
        die("no user id found for invoice  ".$invoiceId);       
    }
    
    //get all the currencies
    $result = localAPI('GetCurrencies', array());
    $total_currencies = $result['totalresults'];
        if ($result['result'] == 'success') {
            if ($total_currencies > 1) {
                if ($currency != 'USD') {
                //get the rate and make the calculations
                    foreach($result['currencies']['currency'] as $currencies) {
                        if ($currencies['code'] == $currency) {
                            $rate = $currencies['rate'];
                            break;
                       }     
                    }
                    
                $total = ($invoice_price / $rate);
                $amount = number_format($total,2);
                }
            }
        } else {
            error_log('unable to get currencies ');
            die("unable to get currencies");      
        }
        
} else {
    //else go along with the invoice price, considering it is defaulted on USD
    $postData = array('invoiceid' => $invoiceId); 
    $data = localAPI('GetInvoice', $postData);

    if (!$data) {
        error_log('No invoice found for invoice id' . $invoiceId);
        die("Invalid invoice. ".$invoiceId);
    }

    $amount = $data['total'];
    $notes = $data['notes'];
    
}

if (!$secretID || !$vendorID)
{
    echo 'Plugin is not fully configured. Please select different payment option';
    exit;
}

if ($amount <= 0) {
    error_log('Plugin error. Amount is negative or 0 => '.$amount);
    echo 'Plugin is not fully configured. Please select different payment option. Amount is negative or 0 => '.$amount;
    exit;
}

$orderDescription = "Order #{$invoiceId}";
$callbackUrl = $options['systemURL'] . '/modules/gateways/callback/litepay.php?invoice_id=' . $invoiceId .'&secret='. $secretID;
$successUrl = $options['systemURL'] . '';
//in the future.
$cancelUrl = $options['systemURL'] . '/modules/gateways/callback/litepay.php?cancel&invoice_id=' . $invoiceId;


$client = new MerchantClient($merchantApiUrl, $secretID, $vendorID);
$orderRequest = new CreateOrderRequest($invoiceId, $amount, $callbackUrl, $successUrl);
$response = $client->createOrder($orderRequest);


if ($response instanceof ApiError) {
    error_log('Error: '.$response);
    exit('Error: contact the mother ship. ');
} else {
    $url = $response->getUrl();
    header('Location: ' . $url);
}
?>
