LITEPAY OpenCart Bitcoin Payment Extension
=======================================

This is a OpenCart Bitcoin Payment module for OpenCart from LITEPAY.ch, which allows your shop to accept bitcoin payments in minutes. It is based on LITEPAY.ch API, you can read about it at https://litepay.ch/docs/. 
Instalation takes a minute, upload the files from this archive in your root folder and activate it. Note: you will need to register for a vendor id in order for it to work.

**REGISTRATION**

1. In order for the plugin to work, you will need to register for a Secret Key and VendorID on our website. 
   Please use the following link to register for Merchant API https://litepay.ch/merchant/ 
2. Once you have received the Secret Key and VendorID (by email), you can continue with the Instalation.


**INSTALLATION**

1. Upload module content to your OpenCart folder.
    
**CONFIGURATION**

2. Go to Admin -> Extensions -> Payments
3. Look up "LitePay.ch PayGate" and press "+" (install), then click the pencil (edit)
4. Enter
   - Secret Key; (You got when registering on our website)
   - Vendor ID; (You got when registering on our website)
5. Select Paid status:
   - choose the status you want the order to be after it has been paid.
6. Select "Enabled" to Enabled to activate the plugin.

== Frequently Asked Questions ==

= How does the plugin works? =

  Quite easy, once a order has been created and the user proceeded to checkout, the plugin will redirect to the LitePay.ch merchant payment page, 
  where the buyer will be instructed to pay the invoice. If the invoice has been paid, the buyer will be redirected back to the website where he 
  placed the order, displaying the created order. If the invoice is not paid, it will remain in limbo (30 days) until its paid. 

= Currencies and crypto coins? =
  For accepted currencies please visit https://litepay.ch/docs/.

= The plugin does not work =
  Make sure you have the correct OpenCart version installed, and the VendorID and Secret Key correctly written in the settings page.
  - plugin was tested on version 3.x
  You can contact us with screenshots of the errors to info@litepay.ch and we will provide support.   


**INFORMATION** 
LITEPAY OpenCart Bitcoin Payment Extension v1

If you need any further support regarding our services you can contact us via:
E-mail: [info@litepay.ch]
Web: [https://litepay.ch]
Telegram: [https://t.me/litepay_ch]

Bitcoin wallets you can use:
Electrum: [https://electrum.org]
Jaxx: [https://jaxx.io]
