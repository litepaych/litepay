<?php

// Heading
$_['heading_title']      = 'Litepay.ch';

// Text
$_['text_default_title'] = 'Litepay.ch Crypto Paygate';
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified the details!';
$_['text_on']            = 'On';
$_['text_off']           = 'Off';
$_['text_litepay']   = '<a target="_blank" href="https://litepay.ch"><img src="https://litepay.ch/assets/new/img/logo_litepay_2020_blue.png" height="25" alt="Litepay.ch" title="Litepay.ch" style="border: 1px solid #EEEEEE;" /></a>';

// Entry
$_['entry_title'] = 'Title:';
$_['entry_secret']      = 'Secret Key:';
$_['entry_vendor']     = 'Vendor ID:';
$_['entry_display_payments'] = 'Enabled';
$_['entry_display_payments_status'] = 'Paid Status:';


$_['text_edit']          = 'Edit Litepay.ch';
$_['entry_status']       = 'Status:';
$_['entry_sort_order']   = 'Sort Order:';

// Help
$_['help_callback']      = '';
$_['help_title']      = 'Title shown to your customers';
$_['help_vendorid'] = 'VendorID looks like this XXXXXX';
$_['help_secretkey'] = 'SecretKey looks like this a6bb847d-0b78-478f-a892-d0e402b6390e';
$_['help_payments_status'] = 'Choose the status you want the order to be after it has been paid.';

// Text
$_['heading_title']      = 'Litepay.ch';
$_['text_title']         = 'Litepay.ch';
