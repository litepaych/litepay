<?php

require_once DIR_SYSTEM . 'library/litepay/LPMerchantClient.php';

function convertToBTCFromSatoshi($value) {
    $BTC = $value / 100000000;
    return $BTC;
}
function convertToSatoshiFromBTC($value) {
    $BTC = $value * 100000000;
    return $BTC;
}
function formatBTC($value) {
    $value = sprintf('%.8f', $value);
    $value = rtrim($value, '0');
    return $value;
}

class ControllerExtensionPaymentLitepay extends Controller
{
    const merchantApiUrl = 'https://litepay.ch/p/';
    var $time = 600;
       
    public function index()
    {
        $data['action'] = $this->url->link('extension/payment/litepay/confirm', '', 'SSL');
        $data['button_confirm'] = $this->language->get('button_confirm');
        $data['button_back'] = $this->language->get('button_back');
        $this->language->load('extension/payment/litepay');
        if ($this->request->get['route'] != 'checkout/guest/confirm') {
            $data['back'] = HTTPS_SERVER . 'index.php?route=checkout/payment';
        } else {
            $data['back'] = HTTPS_SERVER . 'index.php?route=checkout/guest';
        }
        $this->load->model('checkout/order');
        if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/extension/payment/litepay')) {
            return $this->load->view($this->config->get('config_template') . '/template/extension/payment/litepay', $data);
        } else
        {
            return $this->load->view('extension/payment/litepay', $data);
        }
    }
    public function confirm()
    {
        $secretKey = $this->config->get('payment_litepay_secret');
        $vendorID = $this->config->get('payment_litepay_vendor');
        if (!$secretKey || !$vendorID) {
            $this->scError('Check admin panel');
        }
        $this->load->model('checkout/order');
        $order = $this->model_checkout_order->getOrder($this->session->data['order_id']);
        if ($order['custom_field']) {
            $orderUrl = $order['custom_field']['url'];
            $time = $order['custom_field']['time'];
            if ($orderUrl && $time && ($time + $this->time) > time()) {
                header('Location: ' . $orderUrl);
            } else {
                $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], 14);
                header('Location: ' . $this->url->link('common/home'));
                exit;
            }
        }
        $currency = $order['currency_code'];
        $amount =  round(($order['total'] * $this->currency->getvalue($order['currency_code'])),2);
        $orderId = $order['order_id'];
        $callbackUrl = HTTPS_SERVER . 'index.php?route=extension/payment/litepay/callback?invoice_id='.$orderId.'&secret='.md5($secretKey);
        $successUrl = HTTPS_SERVER . 'index.php?route=extension/payment/litepay/accept';
        $client = new LPMerchantClient(self::merchantApiUrl, $secretKey, $vendorID);
        $orderRequest = new CreateOrderRequest($orderId, $amount, $callbackUrl, $successUrl, $currency, $order['email']);
        $response = $client->createOrder($orderRequest);
        if ($response instanceof ApiError) {
            throw new Exception('Error status: ' . $response->getStatus() . '. Message: ' . $response->getMessage());
        }  else {
                $getUrl = $response->getUrl();
                //Order status Pending
                $this->model_checkout_order->addOrderHistory($orderId, 1);
                $this->db->query('UPDATE `' . DB_PREFIX . 'order` SET custom_field =\'' . serialize(array('url' => $getUrl, 'time' => time())) . '\' WHERE order_id=\'' . $orderId . '\'');
                header('Location: ' . $getUrl);
            }
        }
        public function accept()
    {
        if (isset($this->session->data['user_token'])) {
            $this->response->redirect(HTTPS_SERVER . 'index.php?route=checkout/success&user_token=' . $this->session->data['user_token']);
        } else {
            $this->response->redirect(HTTPS_SERVER . 'index.php?route=checkout/success');
        }
    }
    
    public function callback() {
        $secretKey = $this->config->get('payment_litepay_secret');
        $vendorID = $this->config->get('payment_litepay_vendor');
        $status = $this->config->get('payment_litepay_payments_status');
        $this->load->model('checkout/order');
        if ($_SERVER['REQUEST_METHOD'] != 'GET') { exit; }
        $client = new LPMerchantClient(self::merchantApiUrl, $secretKey, $vendorID);
        $callback = $client->parseCreateOrderCallback($_REQUEST);
        if (!$callback) {exit('wrong callback');}
        $orderId = $callback->invoiceID();
        $order = $this->model_checkout_order->getOrder($orderId);
        $note = "Received payment of ". formatBTC(convertToBTCFromSatoshi($callback->value())) ." ".$callback->coin()." trough address ". $callback->input_address() .". TxID: ". $callback->transaction_hash() .", current confirmations: ". $callback->confirmations() ." for invoiceID: ".$callback->invoiceID();
        if (md5($secretKey) == $callback->secretID()) {
            if ($order['order_status_id'] != $status) {
                $this->model_checkout_order->addOrderHistory($orderId, $status, $note, 1);
                echo '*ok*';
            } elseif ($order['order_status_id'] == $status) {
                $this->model_checkout_order->addOrderHistory($orderId, $status, $note, 1);
                echo '*ok*';
            } else {
                echo 'Something is wrong!';
            }
        }
    }
}