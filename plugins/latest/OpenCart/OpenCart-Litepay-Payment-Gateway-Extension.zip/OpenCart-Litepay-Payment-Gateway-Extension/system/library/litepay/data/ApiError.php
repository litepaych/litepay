<?php

class ApiError
{
	private $status;
	private $message;

	/**
	 * @param $status
	 * @param $message
	 */
	function __construct($status, $message)
	{
		$this->status = $status;
		$this->message = $message;
	}

	/**
	 * @return String
	 */
	public function getStatus()
	{
		return $this->status;
	}

	/**
	 * @return String
	 */
	public function getMessage()
	{
		return $this->message;
	}


}