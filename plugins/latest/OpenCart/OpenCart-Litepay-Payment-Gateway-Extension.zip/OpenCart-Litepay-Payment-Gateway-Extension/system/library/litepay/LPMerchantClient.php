<?php


include_once('components/FormattingUtil.php');
include_once('data/ApiError.php');
include_once('data/OrderCallback.php');
include_once('messages/CreateOrderRequest.php');
include_once('messages/CreateOrderResponse.php');


class LPMerchantClient
{

	private $merchantApiUrl;
	private $secretID;
	private $vendorID;
	private $debug;
	/**
	 * @param $merchantApiUrl
	 * @param $secretID
	 * @param $vendorID
	 * @param bool $debug
	 */
	function __construct($merchantApiUrl, $secretID, $vendorID, $debug = false)
	{
		$this->merchantApiUrl = $merchantApiUrl;
		$this->secretID = $secretID;
		$this->vendorID = $vendorID;
		$this->debug = $debug;
	}

	/**
	 * @param CreateOrderRequest $request
	 * @return ApiError|CreateOrderResponse
	 */
	public function createOrder(CreateOrderRequest $request)
	{
		$payload = array(
                            'vendor' => $this->vendorID,
                            'secret' => $this->secretID,
                            'invoice' => $request->getOrderId(),
                            'price' => $request->getPayAmount(),
                            'currency' => $request->getCurrency(),
                            'email' => urlencode($request->getEmail()),
                            'callbackUrl' => urlencode($request->getCallbackUrl()),
                            'returnUrl' => urlencode($request->getSuccessUrl())
                        );

		if (!$this->debug) {
			if ($this->merchantApiUrl && $payload) {
                            $ch=curl_init();
                            curl_setopt($ch, CURLOPT_URL, $this->merchantApiUrl);
                            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                            curl_setopt($ch, CURLOPT_POST, 1);
                            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($payload));
                            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
                            curl_setopt($ch, CURLOPT_TIMEOUT, 100);
                            $response = curl_exec($ch);
                            if (curl_errno($ch)) {
                                throw new \Exception('Connection Error: ' . curl_errno($ch) . ' - ' . curl_error($ch));
                            }
                            curl_close($ch);

                            if ($response != null) {
                                $body = (object)array();
                                $data = json_decode($response);
				if ($data->status == 'success') {
                                    $body->url = $data->url;
                                    return new CreateOrderResponse($body->url);
                                } else {
                                    return new ApiError($data->status, $data->message);
                                }
			} else {
				exit('Error empty reply from the server');
			}
                           
                       }
		} else {
			exit();
		}
	}

	/**
	 * @param $r $_REQUEST
	 * @return OrderCallback|null
	 */
	public function parseCreateOrderCallback($r)
	{
		$result = null;

		if ($r != null && isset($r['invoice_id'], $r['secret'], $r['destination_address'], $r['input_address'], $r['value'], $r['confirmations'], $r['transaction_hash'], $r['coin'])) {
                    $result = new OrderCallback($r['invoice_id'], $r['secret'], $r['destination_address'], $r['input_address'], $r['value'], $r['confirmations'], $r['transaction_hash'], $r['coin']);
		}

		return $result;
	}

}