<?php
class ControllerExtensionPaymentLitepay extends Controller
{
    private $error = array();
    private $langs = array('heading_title', 'text_edit', 'text_enabled', 'text_disabled', 'text_all_zones', 'text_none',
        'text_yes', 'text_no', 'text_off', 'entry_sign', 'entry_lang', 'help_lang', 'entry_test',
        'entry_order_status', 'entry_geo_zone', 'entry_receive_currency', 'entry_status', 'entry_default_payments', 'entry_display_payments', 'entry_display_payments_status',
        'entry_sort_order', 'help_callback', 'button_save', 'button_cancel', 'tab_general', 'entry_secret', 'text_default_title', 'entry_title',
        'text_litepay', 'entry_vendor', 'help_payments_status'
    );

    public function index() {
        $this->load->model('localisation/order_status');
        $this->load->language('extension/payment/litepay');
        $this->document->setTitle($this->language->get('heading_title'));
        $this->load->model('setting/setting');

        if ($this->request->server['REQUEST_METHOD'] == 'POST') {
            if($this->validate()) {
                $this->load->model('setting/setting');
                if (empty($this->request->post['payment_litepay_secret'])) {
                    $this->request->post['payment_litepay_secret'] = $this->config->get('payment_litepay_secret');
                }
                $this->model_setting_setting->editSetting('payment_litepay', $this->request->post);
                $this->session->data['success'] = $this->language->get('text_success');
                $this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
            }
        }
        $data = array();
        $this->loadLang($data);

        if (!empty($this->error)) {
            foreach ($this->error as $key=>$error) {
                $data['error_' . $key] = $error;
            }
        }

        $this->loadBreadcrumbs($data);
        $data['action'] = $this->url->link('extension/payment/litepay', 'user_token=' . $this->session->data['user_token'], 'SSL');
        $data['cancel'] = HTTPS_SERVER . 'index.php?route=extension/payment&user_token=' . $this->session->data['user_token'];

        $this->loadFromRequestOrFromConfig($data, 'payment_litepay_vendor');
        $this->loadFromRequestOrFromConfig($data, 'payment_litepay_title');
        $this->loadFromRequestOrFromConfig($data, 'payment_litepay_secret');
        $this->loadFromRequestOrFromConfig($data, 'payment_litepay_status');
        $this->loadFromRequestOrFromConfig($data, 'payment_litepay_payments_status');
        $this->loadFromRequestOrFromConfig($data, 'payment_litepay_sort_order');
        $data['callback'] = HTTP_CATALOG . 'index.php?route=payment/litepay/callback';
        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $html = array();
        if (is_numeric($data['payment_litepay_payments_status'])) {
            foreach ($data['order_statuses'] as $statuses ) {
                if (is_array($statuses)) {
                    if ($statuses['order_status_id'] === $data['payment_litepay_payments_status']) {
                        $html[] = '<option value="'.$statuses['order_status_id'].'" selected="selected">('.$statuses['order_status_id'].') '.$statuses['name'].'</option>';
                    } else {
                        $html[] = '<option value="'.$statuses['order_status_id'].'">('.$statuses['order_status_id'].') '.$statuses['name'].'</option>';
                    }
                }
            }
        } else {
            foreach ($data['order_statuses'] as $statuses ) {
                if (is_array($statuses)) {
                    if ($statuses['order_status_id'] === 1) {
                        $html[] = '<option value="'.$statuses['order_status_id'].'" selected="selected">('.$statuses['order_status_id'].') '.$statuses['name'].'</option>';
                    } else {
                        $html[] = '<option value="'.$statuses['order_status_id'].'">('.$statuses['order_status_id'].') '.$statuses['name'].'</option>';
                    }
                }
            }
        }
        sort($html);
        $data['html'] = implode($html);
        $this->template = 'extension/payment/litepay';

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view($this->template, $data));
    }

    private function loadLang(&$data) {
        foreach ($this->langs as $lang) {
            $data[$lang] = $this->language->get($lang);
        }
    }

    private function loadFromRequestOrFromConfig(&$data, $key) {
        if (isset($this->request->post[$key])) {
            $data[$key] = $this->request->post[$key];
        } else {
            $data[$key] = $this->config->get($key);
        }
    }

    private function loadBreadcrumbs(&$data) {
        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_payment'),
            'href' => $this->url->link('extension/payment', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('payment/litepay', 'user_token=' . $this->session->data['user_token'], 'SSL')
        );
    }

    private function validate() {
        if (!$this->user->hasPermission('modify', 'extension/payment/litepay')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        return !$this->error;
    }
}