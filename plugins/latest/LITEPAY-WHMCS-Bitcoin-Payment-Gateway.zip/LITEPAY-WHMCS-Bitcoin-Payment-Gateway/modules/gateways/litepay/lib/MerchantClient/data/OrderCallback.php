<?php
		
class OrderCallback
{
	private $invoiceID;
	private $secretID;
	private $destination_address;
	private $input_address;
	private $value;
	private $confirmations;
	private $transaction_hash;
        private $coin;

        
	function __construct($invoiceID, $secretID, $destination_address, $input_address, $value, $confirmations, $transaction_hash, $coin)
	{
		$this->invoiceID = $invoiceID;
		$this->secretID = $secretID;
		$this->destination_address = $destination_address;
		$this->input_address = $input_address;
		$this->value = $value;
		$this->confirmations = $confirmations;
		$this->transaction_hash = $transaction_hash;
                $this->coin = $coin;
	}
	
	/**
	 * @return mixed
	 */
	public function invoiceID()
	{
		return $this->invoiceID;
	}

	/**
	 * @return mixed
	 */
	public function secretID()
	{
		return $this->secretID;
	}

	/**
	 * @return mixed
	 */
	public function destination_address()
	{
		return $this->destination_address;
	}

	/**
	 * @return mixed
	 */
	public function input_address()
	{
		return $this->input_address;
	}

	/**
	 * @return mixed
	 */
	public function value()
	{
		return FormattingUtil::formatCurrency($this->value == null ? 0.0 : $this->value);
	}

	/**
	 * @return mixed
	 */
	public function confirmations()
	{
		return $this->confirmations;
	}


	/**
	 * @return mixed
	 */
	public function transaction_hash()
	{
		return $this->transaction_hash == null ? '' : $this->transaction_hash;
	}

	public function coin()
	{
		return $this->coin;
	}

} 