<?php
include '../../../init.php';
include '../../../includes/functions.php';
include '../../../includes/gatewayfunctions.php';
include '../../../includes/invoicefunctions.php';
require_once 'lib/MerchantClient/MerchantClient.php';

$gatewaymodule = "litepay";
$GATEWAY = getGatewayVariables($gatewaymodule);
$options = $_POST;
$invoiceId = (int)$_POST['invoiceId'];
$secretID = $GATEWAY['secretID'];
$vendorID = $GATEWAY['vendorID'];
$merchantApiUrl = 'https://litepay.ch/p/';

//accepting invoice currency as is, any other currency that is not listed on litepay.ch will default to USD
$get_invoice_data = localAPI('GetInvoice',['invoiceid' => $invoiceId]);
if ($get_invoice_data != 'success') {
    $userid = $get_invoice_data['userid'];
    $amount = $get_invoice_data['total'];
    $notes = $get_invoice_data['notes'];
} else { error_log('No invoice found for invoice id' . $invoiceId); die("Invalid invoice. " . $invoiceId); }

//get currency here
$get_invoices = localAPI('GetInvoices', ['userid' => $userid,'limitnum' => 1,'orderby' => $invoiceId]);
if (!$get_invoices) {error_log('No invoice found for invoice id' . $invoiceId); die("Invalid invoice. " . $invoiceId);}
$data = (object)$get_invoices['invoices']['invoice'][0];

//get user email.
$get_user_data = localAPI('GetClientsDetails', ['clientid' => $userid]);
if (!$get_user_data) { error_log('No user id found'); die("No user id found");}
$email = $get_user_data['email'];


if (!$secretID || !$vendorID) { exit('Plugin is not fully configured. Please select different payment option');}
if ($amount <= 0) { error_log('Plugin error. Amount is negative or 0 => '.$amount); exit( 'Plugin is not fully configured. Please select different payment option. Amount is negative or 0 => '.$amount);}
      
    
if (substr($options['systemURL'], -1) != "/") {  $systemurl = $options['systemURL'] . "/";  } else { $systemurl = $options['systemURL']; }

$orderDescription = "Order #{$invoiceId}";
$callbackUrl = $systemurl . 'modules/gateways/callback/litepay.php?invoice_id=' . $invoiceId .'&secret='. $secretID;
$successUrl = $systemurl . '';

$client = new MerchantClient($merchantApiUrl, $secretID, $vendorID);
$orderRequest = new CreateOrderRequest($invoiceId, $amount, $callbackUrl, $successUrl, $data->currencycode, $email);
$response = $client->createOrder($orderRequest);

if ($response instanceof ApiError) { error_log('Error: '.$response); exit('Error: contact the mother ship. '); } else { $url = $response->getUrl(); header('Location: ' . $url); }

?>
