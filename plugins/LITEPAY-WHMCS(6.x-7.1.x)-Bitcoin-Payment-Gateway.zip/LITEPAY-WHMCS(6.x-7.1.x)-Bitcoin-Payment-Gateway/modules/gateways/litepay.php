<?php

function litepay_config()
{
    $configarray = array(
        "FriendlyName" => array(
            "Type"         => "System",
            "Value"        =>"LitePay.ch Crypto PayGate"
        ),
        'secretID' => array(
            "FriendlyName" => "Secret Key",
            "Type"         => "text",
            "Default"      => "Secret Key",
        ),
        "vendorID" => array(
            "FriendlyName" => "Vendor ID",
            "Type"         => "text",
            "Default" => "Vendor ID",
        ),
    );
    return $configarray;
}
/**
 * @param array $params
 *
 * @return string
 */
function litepay_link($params)
{
    # Invoice Variables
    $invoiceid = $params['invoiceid'];
    # Client Variables
    $firstname = $params['clientdetails']['firstname'];
    $lastname  = $params['clientdetails']['lastname'];
    $email     = $params['clientdetails']['email'];
    $address1  = $params['clientdetails']['address1'];
    $address2  = $params['clientdetails']['address2'];
    $city      = $params['clientdetails']['city'];
    $state     = $params['clientdetails']['state'];
    $postcode  = $params['clientdetails']['postcode'];
    $country   = $params['clientdetails']['country'];
    $phone     = $params['clientdetails']['phonenumber'];
    # System Variables
    if (substr($params['systemurl'], -1) != "/") {
      $systemurl = $params['systemurl'] . "/";
    } else {
      $systemurl = $params['systemurl'];
    }
    
    $post = array(
        'invoiceId'     => $invoiceid,
        'systemURL'     => $systemurl,
        'buyerName'     => "$firstname $lastname",
        'buyerAddress1' => $address1,
        'buyerAddress2' => $address2,
        'buyerCity'     => $city,
        'buyerState'    => $state,
        'buyerZip'      => $postcode,
        'buyerEmail'    => $email,
        'buyerPhone'    => $phone,
    );
    $form = '<form action="'.$systemurl.'modules/gateways/litepay/order.php" method="POST">';
    foreach ($post as $key => $value) {
        $form.= '<input type="hidden" name="'.$key.'" value = "'.$value.'" />';
    }
    $form.='<input type="submit" value="'.$params['langpaynow'].'" />';
    $form.='</form>';
    return $form;
}